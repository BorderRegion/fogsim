/*
  Copyright 2012 by James McDermott
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
*/


package ec.app.gpsemantics.func;
import ec.*;
import ec.gp.*;
import ec.util.*;

/*
 * SemanticX15.java
 *
 */

/**
 * @author James McDermott
 */

public class SemanticX15 extends SemanticNode
    {
    public char value() { return 'X'; }
    public int index() { return 15; }
    }
